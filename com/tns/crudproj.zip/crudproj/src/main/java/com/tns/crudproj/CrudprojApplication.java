package com.tns.crudproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudprojApplication.class, args);
	}

}
