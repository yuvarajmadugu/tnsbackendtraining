package com.tns.crudproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
